package org.rmi;

public interface Calculation {
int cube(int number);
}
