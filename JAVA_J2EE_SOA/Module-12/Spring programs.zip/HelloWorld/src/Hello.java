public class Hello  {
   public String msg;

   public void setMsg(String msg){
      this.msg  = msg;
   }

   public void getMsg(){
      System.out.println("Your Message : " + msg);
   }

}