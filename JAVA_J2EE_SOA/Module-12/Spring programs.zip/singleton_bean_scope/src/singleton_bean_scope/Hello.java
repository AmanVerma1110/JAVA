package singleton_bean_scope;

public class Hello {
	     String Msg;

	   public void setMsg(String Msg){
	      this.Msg  = Msg;
	   }

	   public void getMsg(){
	      System.out.println("Your Message : " + Msg);
	   }	

	}
